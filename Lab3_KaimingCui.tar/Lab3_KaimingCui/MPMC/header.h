/**
 *Kaiming Cui
 *CSCI 503
 *Lab3
 *The tar ball contains a Makefile, a source codThe tar ball "Lab3_KaimingCui.tar" contains 2 file directories: MPMC and PMM. Each directory contains four items: a executable file "KaimingCuiMPMC(PMM).out", a source code file "MPMC.c(PMM.c)", a Makefile a README.txt, and this header.h file.
 *
 */
